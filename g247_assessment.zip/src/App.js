import './App.scss';
import Wrapper from './components/Wrapper';

function App() {
  return (
    <>
    <Wrapper/>
    </>
  );
}

export default App;
