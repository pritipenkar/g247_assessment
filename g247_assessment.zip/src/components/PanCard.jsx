import React from 'react'

const PanCard = () => {
  return (
    <div>
    <img src='/pan-card-img.png' alt='PAN Card'/>
    </div>
    
  )
}

export default PanCard